#include <mega128.h>
#include <delay.h>
void main(void)
{
    unsigned Step[4] = {0x03, 0x06, 0x0c, 0x09};
    int i;
    DDRC = 0xff;
    PORTC = 0x00;
        while(1)
        {
            for(i=0; i<=3; i++)
            {
            PORTC = Step[i];
            delay_ms(50);
            }
        }
}